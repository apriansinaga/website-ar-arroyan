( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#university-hub-settings-metabox-container' ).tabs();

	});

} )( jQuery );
